export default function Hello() {
  return <h1>Hello Page (you should be redirected from this)</h1>;
}