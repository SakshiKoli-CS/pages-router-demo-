export default function Welcome() {
  return <h1>🎉 Welcome Page - You were redirected here!!!</h1>;
}